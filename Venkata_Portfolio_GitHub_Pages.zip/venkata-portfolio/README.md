# Venkata Palacherla — portfolio

A personal engineering and research website. Plain HTML, CSS, and a small amount of JavaScript. No build tools, dependencies, analytics, or backend.

## Preview

Open `index.html` directly in a browser, or run:

```sh
python3 -m http.server 8000
```

Then open http://localhost:8000.

## GitHub Pages

Recommended repository name: `venkataPalacherla.github.io` under the `venkataPalacherla` account. A project repository also works; all asset paths are relative.

1. Create an empty **private** repository on GitHub (do not initialize it with a README). Keep Pages disabled while reviewing the site.
2. From this directory, run:

   ```sh
   git remote add origin https://github.com/venkataPalacherla/venkataPalacherla.github.io.git
   git push -u origin main
   ```

   If starting from the ZIP rather than the existing Git checkout, first run:

   ```sh
   git init -b main
   git add .
   git commit -m "Build personal robotics portfolio"
   ```

3. In repository **Settings → Pages → Build and deployment**, choose **GitHub Actions**.
4. Run **Deploy portfolio to GitHub Pages** from the Actions tab if the first push happened before Pages was configured.

Deployment is manual-only. Pushing code does not publish the website. Enable Pages and run the workflow only when you are ready to publish and have verified the desired access settings.

## Editing

- `index.html`: biography, experience, papers, projects, and contact links.
- `styles.css`: typography, colors, spacing, and responsive layout.
- `script.js`: contribution disclosure.
- `assets/resume.pdf`: downloadable resume.
- `assets/`: project figures and animations.
- `.github/workflows/pages.yml`: deployment workflow.

The page renders its content without JavaScript. The contribution disclosure is enhanced with JavaScript. The site uses system fonts; it makes no font-service requests.

## Content notes

- Content is based on the resume supplied on October 18, 2026, and the linked public project READMEs.
- The resume lists overlapping Cohesive and Skylla dates. The page describes the Cohesive role as “Current” until the precise timeline is confirmed.
- Papers use the published author name **P. V. Amith**.
- Add a personal portrait when a preferred photo is available. The website does not use a generated portrait or a placeholder photo.
- The original resume PDF contains the supplied professional contact details, including a phone number.

## Asset credits

Project figures and animations were retrieved from the corresponding public repositories:

- `assets/visual-odometry.png`: [Attention-Based-Visual-Odometry](https://github.com/venkataPalacherla/Attention-Based-Visual-Odometry), `assets/Trajectory.png`. Collaborative work; see repository acknowledgments and report.
- `assets/quadrotor.gif`: [Quadrotor-Control-with-LQR-iLQR](https://github.com/venkataPalacherla/Quadrotor-Control-with-LQR-iLQR), `Assets/LQRController.gif`.
- `assets/pendulum.gif`: [Pendulum-control-with-Q-learning](https://github.com/venkataPalacherla/Pendulum-control-with-Q-learning), `Assets/inversePendulum.gif`.

Layout is newly implemented, inspired by the restrained personal/research presentation at https://raktimgg.github.io/. No source code, biography, or images were copied from that website.
